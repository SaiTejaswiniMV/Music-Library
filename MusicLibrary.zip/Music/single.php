<?php
	ob_start();
?>
<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
body{background-image:url(back.jpg);background-repeat:no-repeat;background-size:100% 100%;}
h1{color:aqua;font-family: Cursive;}
h5{color:aqua;font-family: Cursive;}
a{color:aqua;font-weight:bold;font-family:Baskerville Old Face;}
p{color:aqua;font-weight:bold;font-family:Baskerville Old Face;}
</style>
<title>Music Library</title>
</head>
<body >

<center><h1> Music Library</h1></center>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<a  href="update.html">Change Password</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<a href="welcome.html"> Logout </a>
</br>
<hr>
<a  href="home.php" > Home </a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="insert.html">Insert</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="delete.html">Delete</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="tracks.html">Tracks</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="favourites.php">Favourites</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<br>
<br>

</br>
<?php
session_start();
extract($_GET);

	//Make sure some ISBN is sent
	if($track_name=="")
	{
		echo "<h2>OOPS...PLEASE ENTER SOME NAME..</h2>";
		exit(0);
	}
	
	else
	{
		$conn = mysql_connect("127.0.0.1","root","");
		if(!$conn)
		{
			die("Could not establish connection to MYSQL");
		}
		else
		{
                        $usr=$_SESSION["user_id"];
			$db=mysql_select_db("music", $conn);
			$sql="SELECT track_name FROM tracks WHERE user_id='$usr' and track_name='$track_name'";

			if(!$db)
			{
				
				die("Cannot connect to DB".mysql_error());
			}
			else
			{
			$results=mysql_query($sql, $conn);
				if(!$results)
				{
				//die("Cannot get data".mysql_error());
                                 echo "<center><p> Sorry falied to load  </p></center>";
                                 echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";

                                
				}
				else
				{
					//echo $results;
					echo "<center><p> Play </p></center>";
                                        echo "<br>";
					while($row = mysql_fetch_assoc($results))
					{
					
							
                                                //echo "$row[track_name]".": ";
                                               echo"<center>";			
						echo "<a href="."$row[track_name]". ">";
                                                 echo "$row[track_name]";
                                                 echo "</a>";
                                                 echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                                 echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
                                         echo "</br>";
						echo "</br>";						
					}
					 
				}
			}
		}
	}
			
		//conn.close();	

ob_flush();
flush();
?>	


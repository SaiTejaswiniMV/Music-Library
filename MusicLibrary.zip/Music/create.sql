create table lib_users
	(user_id varchar(10) NOT NULL,
         pass_word varchar(10),
         fname varchar(10),
         lname varchar(10),
         primary key (user_id));

create table albums
	(album_id varchar(10) NOT NULL ,
	 album_name varchar(15) NOT NULL, 
	 year integer ,
         album_size varchar(5),
         composer varchar(15) default 'Unknown',
	primary key (album_id));

create table artist
	(artist_id varchar(10) NOT NULL,
      	artist_name varchar(20) NOT NULL,
        gender varchar(2),
        age integer,
        awards longtext,        
	primary key (artist_id));


create table tracks
	(track_id varchar(10),
         track_name varchar(50),
         user_id varchar(10),
         track_duration float,
         genre varchar(10),
         language varchar(10),
         album_id varchar(10),
         primary key(track_id,track_name,user_id),
         foreign key(album_id) references albums(album_id),
         foreign key(user_id) references lib_users(user_id));
         
create table favourites
	(favourites_id varchar(10) NOT NULL,
         track_id varchar(10),
         user_id varchar(10),
         track_name varchar(50),
         ratings integer,
         primary key (favourites_id,user_id),
         foreign key(user_id) references lib_users(user_id),
         foreign key (track_id,track_name)references tracks(track_id,track_name)); 
create table tracks_singer
(track_id varchar(10) NOT NULL,
  artist_id varchar(10) NOT NULL,
  primary key (track_id,artist_id),
  foreign key (track_id)references tracks(track_id),
foreign key (artist_id)references artist(artist_id));
 





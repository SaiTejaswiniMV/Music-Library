<?php
session_start();
?>
<html>
<head>
<title> Login</title>
<style type="text/css">
body{background-image:url(back.jpg);background-repeat:no-repeat;background-size:100% 100%;}
h1{color:aqua;font-family: Cursive;}
h2{color:aqua;font-family: Cursive;}
label{color:aqua;font-weight:bold;font-family:Baskerville Old Face;}
</style>
<title>Music Library</title>
</head>
<body>
<center><h1>Music Library</h1></center>
<hr>
<br>
<br>
<br>
<br>
<br>
<center>
<h2> Login Page </h2>
<form action="login_pg.php" method="GET">
<label>User_id: </label>
<input type="text" name="user_id"/><br>
<br>
<br>
<label>Password: </label>
<input type="text" name="pwd"/><br><br>


<input type="reset" name="Clear"/>
<input type="submit" value="Submit"/>
</form>
<center>
</body>

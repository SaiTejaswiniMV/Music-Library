<?php
	ob_start();
?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
body{background-image:url(back.jpg);background-repeat:no-repeat;background-size:100% 100%;}
h1{color:aqua;font-family: Cursive;}
h5{color:aqua;font-family: Cursive;}
h2{color:aqua;font-family: Cursive;}
h4{color:aqua;font-family: Cursive;}
a{color:aqua;font-weight:bold;font-family:Baskerville Old Face;}
</style>
<title>Music Library</title>
</head>
<body >

<center><h1> Music Library</h1></center>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<a  href="update.html">Change Password</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<a href="welcome.html"> Logout </a>
</br>
<hr>
<a  href="home.php" > Home </a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="insert.html">Insert</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="delete.html">Delete</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="tracks.html">Tracks</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a  href="favourites.php">Favourites</a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<br>
<br>
<br>
<br>

<?php
//$_SESSION["user_id"] = $user_id;
session_start();
extract($_GET);


	//Make sure some ISBN is sent
	/*if(($user_id=="") || ($pwd==""))
	{
		echo "<center><h2>OOPS...PLEASE FILL ALL FIELDS..</h2></center>";
		exit(0);
	}*/
	
//	else
	//{
		$conn = mysql_connect("127.0.0.1","root","");
		if(!$conn)
		{
			die("Could not establish connection to MYSQL");
		}
		else
		{
                        if($_SESSION["user_id"]=="music01")
                        {
                          $m1="music02"; 
                          $m2="music03";
                         }
                       else if($_SESSION["user_id"]=="music02")
                        {
                          $m1="music01"; 
                          $m2="music03";
                         }
                        else
                        {
                          $m1="music02"; 
                          $m2="music01";
                         }
                       // echo "$m1";
                        //echo "$m2";
			$db=mysql_select_db("music", $conn);
			$sql="SELECT DISTINCT track_name from tracks where track_name not in(select track_name from tracks where user_id<>'$m1' and user_id<>'$m2');";
                        
			if(!$db)
			{
				
				die("Cannot connect to DB".mysql_error());
			}
			else
			{
			$results=mysql_query($sql, $conn);
                        
				if(!$results)
				{
				//die("Cannot get data".mysql_error());
                                 echo "<center><h1> Oops !! Wrong password or user_id <br>";
                                 echo "Please try once more </h1></center>";
				}
				else
				{
					//echo $results;
                                        echo "<h4> \"MUSIC LIBRARY \" ,provides with the user friendly environment where user has full freedom to prioritize their choices,can update and insert the tracks as per their requirement .User can add their favourite tracks as in a special category called favourites and enjoy their favourite tunes.It keeps track of all the users and give recommendations for highly demanded tracks by most of the users.</h4>"; 
 
					echo "<h5> You may also like : </h5>";
                                        
					while($row = mysql_fetch_assoc($results) )
					{
					
							
                                                //echo "$row[track_name]".": ";			
						echo "<a href="."$row[track_name]". ">";
                                                 echo "$row[track_name]";
                                                 echo "</a>";
                                                echo "</br>";
											
					}
                                               echo "</br>";	
                                                  echo "</br>";
						echo "</br>";	
                                                echo "</br>";
						echo "</br>";	
					 
				}
			}
		}
	//}
			
		//conn.close();	

ob_flush();
flush();
?>	


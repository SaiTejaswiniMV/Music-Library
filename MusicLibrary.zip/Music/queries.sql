select favourites_id,track_name from favourites;
select count(*) as total_tracks,user_id from tracks group by user_id;
select artist_name from artist where awards like '%National Film Award%';
select composer from albums where album_id in(select album_id from tracks where track_name='Kabira.mp3');
select distinct track_name from tracks where genre='Romantic';
select artist_name from artist where artist_id in(select distinct artist_id from tracks_singer where track_id in(select distinct track_id from tracks where genre='Romantic'));
select distinct track_name from tracks where track_id in(select track_id from tracks_singer where artist_id in(select artist_id from artist where artist_name='Arijit Singh')) and album_id in(select album_id from albums where album_name='Aashiqui 2');
select distinct track_name from tracks where track_id in(select track_id from tracks_singer where artist_id in(select artist_id from artist where artist_name='Arijit Singh')) and album_id in(select album_id from albums where composer='Ankit Tiwari');
select count(*) from tracks where track_id in(select track_id from tracks_singer where artist_id in(select artist_id from artist where artist_name='Arijit Singh')) and album_id in(select album_id from albums where composer='Ankit Tiwari');
select distinct track_name,ratings from favourites where track_name in(select track_name from tracks where track_id in(select track_id from tracks_singer where artist_id in(select artist_id from artist where artist_name='Shreya Ghosal')) and user_id in(select user_id from lib_users where lname='Tejaswini'));
select album_name from albums where album_id in(select album_id from tracks where track_id in(select track_id from tracks_singer where artist_id in(select artist_id from artist where artist_name='A.R.Rahman')) and year<2015);
select distinct tracks.track_name from tracks left outer join favourites on tracks.track_id=favourites.track_id;
​select track_id,track_name from tracks where track_id not in(select track_id from favourites);
SELECT DISTINCT track_name from tracks where track_name not in(select track_name from tracks where user_id<>'music02' and user_id<>'music03');
select album_id,year from albums group by year;
select user_id,sum(track_duration) from tracks GROUP By user_id HAVING sum(track_duration)>100 order by sum(track_duration);
update favourites set ratings=5 where track_id in (select track_id from tracks_singer where artist_id in(SELECT artist_id from artist where artist_name='Shreya Ghosal'));
select distinct a.album_name,t.track_name from albums a ,tracks t where a.album_id=t.album_id;
SELECT artist_name from artist where artist_id in (SELECT artist_id from tracks_singer where track_id in(SELECT track_id from tracks where track_duration in (select max(track_duration) from tracks)));
​select t.track_name,a.artist_name,t.genre from tracks t,artist a,tracks_singer ts where a.artist_name='Arijit Singh' and ts.artist_id=a.artist_id group by t.genre;
select distinct t.track_id,t.track_name,t.genre,ts.artist_id from tracks t,tracks_singer ts where t.track_id=ts.track_id and ts.artist_id in(select artist_id from artist where age<30);
select distinct t.track_name,t.track_id ,a.artist_name from tracks t ,artist a where track_id in(select track_id from tracks_singer group by track_id having count(artist_id)>1) and a. artist_id in(select artist_id from tracks_singer group by track_id having count(artist_id)>1);

​ 

​
